<?php

require "config.php";

$reservation = $conn->prepare("INSERT INTO reservation(fname,email,phone,date,time,people) VALUES(?,?,?,?,?,?)" );

$reservation->bindParam(1,$_POST["fname"]);
$reservation->bindParam(2,$_POST["email"]);
$reservation->bindParam(3,$_POST["phone"]);
$reservation->bindParam(4,$_POST["date"]);
$reservation->bindParam(5,$_POST["time"]);
$reservation->bindParam(6,$_POST["people"]);
$reservation->execute();

echo"<tr> <td>".$_POST["fname"]."</td> <td>".$_POST["email"]."</td>  <td>".$_POST["phone"]."</td>  <td>".$_POST["date"]."</td>  <td>".$_POST["time"]."</td>  <td>".$_POST["people"]."</td>  



?>