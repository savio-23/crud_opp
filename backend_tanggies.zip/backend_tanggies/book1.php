<?php


require "config.php";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="blue.png">

    <title>Table Booking Final</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'EB Garamond', serif;
        }

        .logo {
            width: 18%;
            height: auto;
            display: block;
            margin: 0 auto;
        }

        .background {
            background-image: url('bg.jpg');
            background-size: cover;
            background-color: rgba(0, 0, 0, 0.7);
        }

        .back {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 20vh;
        }

        .wrapper {
            width: 80%;
            max-width: 500px;
            background: transparent;
            border: 2px solid rgba(255, 255, 255, .2);
            backdrop-filter: blur(20px);
            color: black;
            border-radius: 10px;
            padding: 30px 40px;
            min-height: 10px;
        }

        .wrapper h2 {
            font-size: 36px;
            text-align: center;
            color: lightblue;
            padding-bottom: 20px;
            text-decoration: underline;
        }

        .input-form {
            text-align: left;
            margin-bottom: 15px;
        }

        .input-form label {
            color: lightblue;
            font-size: 20px;
            display: block;
        }

        .input-form input,
        .input-form select {
            width: 100%;
            padding: 10px;
            border: 2px solid lightblue;
            outline: none;
            border-radius: 5px;
            background: transparent;
            color: white;
        }

        .input-form input::placeholder {
            color: rgba(10, 139, 231, 0.2);
        }

        .input-form input:focus {
            border: 3px solid blue;
        }

        .input-form select option {
            background-color: lightblue;
            color: black;
        }

        .input-form select:hover {
            background-color: white;
            color: black;
        }

        .btn {
            width: 100%;
            height: 45px;
            background-color: lightblue;
            border: none;
            outline: none;
            border-radius: 40px;
            box-shadow: 0 0 10px rgba(0, 0, 0, .1);
            cursor: pointer;
            font-size: 16px;
            color: #333;
            font-weight: 600;
            margin-top: 20px;
        }

        .btn:hover {
            background-color: rgb(106, 199, 199);
        }

        @media screen and (max-width: 500px) {
            .wrapper {
                width: 90%;
                margin: 0 auto;
            }
        }

        @import url('https://fonts.googleapis.com/css2?family=EB+Garamond&display=swap');
    </style>
</head>

<body>
    <div class="background">
        <a href="index.html"><img class="logo" src="blue.png" alt="logo"></a>
        <div class="back">
            <div class="wrapper">
                <h2>BOOK YOUR TABLE</h2>
                <form action="registration.php" method="POST" autocomplete="off"  id="myForm">
                    <div class="input-form">
                        <label for="name">Name:</label>
                        <input type="text" id="fname" name="fname" placeholder="Your name." required>
                    </div>
                    <div class="input-form">
                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" placeholder="Your email." required>
                    </div>
                    <div class="input-form">
                        <label for="phone">Phone No.:</label>
                        <input type="tel" id="phone" name="phone" placeholder="Your Ph.No." required>
                    </div>
                    <div class="input-form">
                        <label for="date">Date:</label>
                        <input type="date" id="date" name="date" required>
                    </div>
                    <div class="input-form">
                        <label for="time">Time:</label>
                        <input type="time" id="time" name="time" required>
                    </div>
                    <div class="input-form">
                        <label for="people">Book for:</label>
                        <select name="people" id="people" required>
                            <option value="">Select</option>
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="3">3</option>
                            <option value="4">4</option>
                            <option value="4+">4+</option>
                        </select>
                    </div>
                    <input type="submit" value="Book Now">
                </form>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const form = document.getElementById("myForm");
        
            form.addEventListener("submit", function (event) {
                event.preventDefault(); // Prevent the default form submission behavior
        
                // Get the form data
                const nameInput = form.elements["fname"];
                const emailInput = form.elements["email"];
                const phoneInput = form.elements["phone"];
                const dateInput = form.elements["date"];
                const timeInput = form.elements["time"];
                const peopleInput = form.elements["people"];
        
                // Perform custom validation here
                if (
                    nameInput.value.trim() === "" ||
                    !isValidEmail(emailInput.value) ||
                    !isValidPhoneNumber(phoneInput.value) ||
                    !isValidDateTime(dateInput.value, timeInput.value) ||
                    peopleInput.value === ""
                ) {
                    alert("Please fill in all fields with valid data.");
                } else {
                    // Clear the form
                    form.reset();
        
                    // Display a custom message in an alert
                    alert("Request accepted. We will notify you soon.");
                }
            });
        
            // Function to check if the email is valid (you can customize this)
            function isValidEmail(email) {
                const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
                return emailPattern.test(email);
            }
        
            // Function to check if the phone number is valid (you can customize this)
            function isValidPhoneNumber(phone) {
                const phonePattern = /^\d{10}$/; // Example: 1234567890
                return phonePattern.test(phone);
            }
        
            // Function to check if the date and time are valid (two hours prior to the current time)
            function isValidDateTime(date, time) {
                const inputDateTime = new Date(date + "T" + time);
                const now = new Date();
                const twoHoursBeforeNow = new Date(now);
                twoHoursBeforeNow.setHours(now.getHours() - 2);
        
                return inputDateTime > twoHoursBeforeNow;
            }
        });
        

    </script>
</body>

</html>